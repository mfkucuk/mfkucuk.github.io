import java.util.Scanner;

/**
 * A number game inspired by Ali Erdogan. 
 * @author Mehmet Feyyaz Küçük
 * @version 29.12.2020
*/ 
public class NumberGame
{
    /**
     * Draws the game board
     * @param b is the 2d board
    */ 
    public static void drawBoard(String[][] b)
    {
        for ( int i = 0; i < b.length; i++ )
        {
            for ( int j = 0; j < b[i].length; j++ )
            {
                System.out.print( b[i][j]);
            }
            System.out.println();
        }
    }
    
    /**
     * refreshes the screen 
    */ 
    public static void clearScreen()
    {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
    
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        
        // Constants
        
        // Variables
        int guessFirst;
        int guessSecond;
        int guessThird;
        int lives;
        int guess;
        int first;
        int second;
        int third;
        boolean gameState;
        
        String[][] board = 
        {
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "}, 
          {"8 " ,"|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"7 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"6 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"5 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"4 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"3 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "},
          {"2 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "}, 
          {"1 ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " ", " ", " ", "|", " "},
          {"  ", "+", "-", "-", "-", "+", "-", "-", "-", "+", "-", "-", "-", "+", " "}, 
        };
        
        // Program Code
        
        // Initalization
        lives = 8;
        gameState = true;
        first = (int) (Math.random() * 9 + 1);
        second = (int) (Math.random() * 9 + 1);
        while ( second == first )
        {
            second = (int) (Math.random() * 9 + 1);
        }
        third = (int) (Math.random() * 9 + 1);
        while ( third == first || third == second )
        {
            third = (int) (Math.random() * 9 + 1);
        }
        
        // Game Rules
        System.out.println( "You are trying to guess a 3 digit number in 8 tries.");
        System.out.println( "The number does not contain any 0.");
        System.out.println( "The number has different digit values.");
        System.out.println( "Press enter to continue...");
        scan.nextLine();
        
        // Game Loop
        while ( gameState )
        {
            // Draw board
            clearScreen();
            System.out.println("You have " + lives + " lives left.");
            drawBoard( board);
            
            // Take guess
            System.out.print( "Guess the 3 digit number: ");
            guess = scan.nextInt();
            
            // Split the digits
            guessFirst = guess / 100;
            guessThird = guess % 10;
            guessSecond = ((guess % 100) - guessThird) / 10;
            
            // Update the board
            board[2 * lives - 1][3] = String.valueOf(guessFirst);
            board[2 * lives - 1][7] = String.valueOf(guessSecond);
            board[2 * lives - 1][11] = String.valueOf(guessThird);
            
            // First digit comparison
            if ( guessFirst == first )
            {
                board[2 * lives - 1][14] += "+1 ";
            }
            else if ( guessFirst == second || guessFirst == third )
            {
                board[2 * lives - 1][14] += "-1 ";
            }
            
            // Second digit comparison
            if ( guessSecond == second )
            {
                board[2 * lives - 1][14] += "+1 ";
            }
            else if ( guessSecond == first || guessSecond == third )
            {
                board[2 * lives - 1][14] += "-1 ";
            }   
            
            // Third digit comparison
            if ( guessThird == third )
            {
                board[2 * lives - 1][14] += "+1 ";
            }
            else if ( guessThird == second || guessThird == first )
            {
                board[2 * lives - 1][14] += "-1 ";
            }
            
            // Check for game-win
            if ( guessFirst == first && guessSecond == second && guessThird == third )
            {
                System.out.println( "Congratulations, " + guess + " was the correct number.");
                System.out.println( "You win!");
                System.exit(1);
            }
            
            // Update lives
            lives--;
            
            // Check game state
            if ( lives == 0 )
            {
                clearScreen();
                System.out.println("You have " + lives + " lives left.");
                drawBoard( board);
                gameState = false;
            }
        }
        
        System.out.println( "Sorry, you lose...");
        
        
        // Closing Scanner
        scan.close();
    }
    
}