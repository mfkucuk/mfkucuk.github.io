/**
 * Player class
*/
public class Player
{
    // Properties
    boolean isTurn;
    String tile;
    String name;
    
    // Constructors
    public Player( boolean isTurn, String tile) 
    {
        this.isTurn = isTurn;
        this.tile = tile;
    }
    
    // Methods
    
    public void endTurn()
    {
        isTurn = !isTurn;
    }
    
    public void startTurn()
    {
        isTurn = !isTurn;
    }
    
    public void putTile( int x, int y, String[][] board)
    {
        if ( board[2 * x - 1][2 * y - 1].equals( " ") )
        {
            board[2 * x - 1][2 * y - 1] = tile;
            endTurn();
        }
        else
        {
            System.out.println( "\nThere is already a tile there, try again.\n");
        }
    }
    
    // Getters
    public String getName()
    {
        return name;
    }
    
    public String getTile()
    {
        return tile;
    }
    
    public boolean getTurn()
    {
        return isTurn;
    }
    
    // Setters
    public void setName( String name) 
    {
        this.name = name;
    }
    
    public void setTurn( boolean isTurn)
    {
        this.isTurn = isTurn;
    }
}