import java.util.Scanner;

/**
 * Tic Tac Toe
 * @author Mehmet Feyyaz Kucuk
 * @version 17.12.2020
*/ 
public class Game
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        Board b = new Board();
        Player p1 = new Player(false, "X");
        Player p2 = new Player(false, "O");
        
        // Constants
        
        // Variables
        boolean gameState;
        int x;
        int y;
        
        // Program Code
        System.out.print( "Enter your name player 1: ");
        p1.setName(scan.nextLine());
        
        System.out.print( "Enter your name player 2: ");
        p2.setName(scan.nextLine());
        
        gameState = true;
        while ( gameState )
        {
            b.clearBoard();
            b.drawBoard();
            
            p1.startTurn();
            while ( p1.getTurn() )
            {
                System.out.print( p1.getName() + ", enter X coordinate for your tile: ");
                x = scan.nextInt();
                
                System.out.print( p1.getName() + ", enter Y coordinate for your tile: ");
                y = scan.nextInt();
                
                p1.putTile(y, x, b.board);
                
            }
            
            b.checkBoard( p1);
            
            b.clearBoard();
            b.drawBoard();
            
            p2.startTurn();
            while ( p2.getTurn() )
            {
                System.out.print( p2.getName() + ", enter X coordinate for your tile: ");
                x = scan.nextInt();
                
                System.out.print( p2.getName() + ", enter Y coordinate for your tile: ");
                y = scan.nextInt();
                
                p2.putTile(y, x, b.board);
                
            }
            
            b.checkBoard( p2);
        }
        
        // Closing Scanner
        scan.close();
    }
    
}