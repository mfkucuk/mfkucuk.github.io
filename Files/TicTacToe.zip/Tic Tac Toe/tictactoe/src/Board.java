/**
 * Tic Tac Toe Board
*/
public class Board
{
    // Properties
    String[][] board =
        {
            {" ", " 1", " ", "2", " ", "3"},
            {"1 ", " ", "|", " ", "|", " "},
            {"  ", "-", "+", "-", "+", "-"},
            {"2 ", " ", "|", " ", "|", " "},
            {"  ", "-", "+", "-", "+", "-"},
            {"3 ", " ", "|", " ", "|", " "},
        };        
    
    // Constructors
    
    // Methods
    public void clearBoard()
    {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
    
    public void drawBoard()
    {
        for ( int i = 0; i < 6; i++ )
        {
            for ( int j = 0; j < board[i].length; j++ )
            {
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }
    
    public String processBoard( int i, int j)
    {
        return board[i][j];
    }
    
    public void checkBoard( Player p)
    {
        // Check horizantally
        for ( int i = 1; i < 6; i += 2 )
        {
            if ( board[i][1].equals( p.getTile()) && board[i][3].equals( p.getTile()) && board[i][5].equals( p.getTile()) )
            {
                clearBoard();
                drawBoard();
                System.out.println( p.getName() + " wins!");
                System.exit(1);
            }
        }
        
        // Check vertically
        for ( int i = 1; i < 6; i += 2 )
        {
            if ( board[1][i].equals( p.getTile()) && board[3][i].equals( p.getTile()) && board[5][i].equals( p.getTile()) )
            {
                clearBoard();
                drawBoard();
                System.out.println( p.getName() + " wins!");
                System.exit(1);
            }
        }
        
        // Check diagonally
        if ( board[1][1].equals( p.getTile()) && board[3][3].equals( p.getTile()) && board[5][5].equals( p.getTile()) )
        {
            clearBoard();
            drawBoard();
            System.out.println( p.getName() + " wins!");
            System.exit(1);
        }
        
        if ( board[5][1].equals( p.getTile()) && board[3][3].equals( p.getTile()) && board[1][5].equals( p.getTile()) )
        {
            clearBoard();
            drawBoard();
            System.out.println( p.getName() + " wins!");
            System.exit(1);
        }
        
        // Check for draw
        if ( ! (board[1][1].equals( " ") || board[1][3].equals( " ") || board[1][5].equals( " ") || board[3][1].equals( " ") || board[3][3].equals( " ") || board[3][5].equals( " ") ||
        board[5][1].equals( " ") || board[5][3].equals( " ") || board[5][5].equals( " ")) )
        {
            // Check horizantally
            for ( int i = 1; i < 6; i += 2 )
            {
                if ( board[i][1].equals( p.getTile()) && board[i][3].equals( p.getTile()) && board[i][5].equals( p.getTile()) )
                {
                    clearBoard();
                    drawBoard();
                    System.out.println( p.getName() + " wins!");
                    System.exit(1);
                }
            }
            
            // Check vertically
            for ( int i = 1; i < 6; i += 2 )
            {
                if ( board[1][i].equals( p.getTile()) && board[3][i].equals( p.getTile()) && board[5][i].equals( p.getTile()) )
                {
                    clearBoard();
                    drawBoard();
                    System.out.println( p.getName() + " wins!");
                    System.exit(1);
                }
            }
            
            // Check diagonally
            if ( board[1][1].equals( p.getTile()) && board[3][3].equals( p.getTile()) && board[5][5].equals( p.getTile()) )
            {
                clearBoard();
                drawBoard();
                System.out.println( p.getName() + " wins!");
                System.exit(1);
            }
            
            else if ( board[5][1].equals( p.getTile()) && board[3][3].equals( p.getTile()) && board[1][5].equals( p.getTile()) )
            {
                clearBoard();
                drawBoard();
                System.out.println( p.getName() + " wins!");
                System.exit(1);
            }
            else 
            {
                clearBoard();
                drawBoard();
                System.out.println( "It's a draw!");
                System.exit(1);
            }
        }
        
    } 
}