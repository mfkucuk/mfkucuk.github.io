/**
 * Player class
*/
public class Player
{
    // Properties
    int x;
    int y;   // x, y positions
    int gold;
    int hp;
    int att;
    int exp;
    int level;
    char tile;
    char dir;
    boolean isYourTurn;
    String message;
    
    // Constructors
    public Player( char tile, boolean isYourTurn)
    {
        this.tile = tile;
        this.isYourTurn = isYourTurn;
        gold = 0;
        message = "";
        exp = 0;
        level = 1;
        hp = 5;
        att = 1;
    }
    
    // Methods
    public void levelUp()
    {
        if ( exp >= 5 )
        {
            level++;
            exp = 0;
            hp += 3;
            att += 1;
        }
    }
    
    public void addMessage( String message)
    {
        this.message += message;
    }
    
    public void add( int val)
    {
        gold += val;
    }
    
    public void changeTurn()
    {
        isYourTurn = ! isYourTurn;
    }
    
    // Setters
    public void setPosition( int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    public void setDir( char dir)
    {
        this.dir = dir;
    }
    
    public void setMessage( String message)
    {
        this.message = message;
    }
    
    // Getters
    public boolean getTurn()
    {
        return isYourTurn;
    }
    
    public char getDir()
    {
        return dir;
    }
    
    public String getMessage()
    {
        return message;
    }
    
}