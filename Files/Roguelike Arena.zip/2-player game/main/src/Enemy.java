/**
 * Enemy class
*/
public class Enemy
{
    // Properties
    int x;
    int y;
    int att;
    int hp;
    char tile;
    
    // Constructors
    public Enemy( int hp, int att, char tile)
    {
        this.hp = hp;
        this.att = att;
        this.tile = tile;
    }
    
    // Methods
    public void setPosition( int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
}
