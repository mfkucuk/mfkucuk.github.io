import java.util.Scanner;

/**
 * Game class
*/
public class Game
{
    Scanner scan = new Scanner(System.in);
    
    // Properties
    Player p1;
    Player p2;
    Enemy e1;
    Enemy e2;
    Enemy e3;
    Enemy e4;
    char[][] map;
    boolean gameState;
    String gameMessage1;
    String gameMessage2;
    
    
    // Constructors
    public Game()
    {
        p1 = new Player('1', true);
        p2 = new Player('2', false);
        
        e1 = new Enemy(2, 1, 's');
        e2 = new Enemy(2, 1, 'S');
        e3 = new Enemy(3, 2, 'g');
        e4 = new Enemy(3, 2, 'G');
        
        map = new char[][]{
            {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
            {'#', 'o', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '2', '#'},
            {'#', '.', '.', '.', '.', '.', '$', '$', '$', '.', '.', '.', '.', '.', '#'},
            {'#', '.', 's', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#', '#'},
            {'#', '.', '.', '.', '.', '#', '#', '#', '#', '#', '.', '.', '.', '.', '#'},
            {'#', '.', '.', '.', '.', '#', '.', '$', '.', '#', '.', '.', '.', '.', '#'},
            {'#', 'C', '.', '.', '.', '#', 'G', 'T', 'g', '#', '.', '.', '.', 'C', '#'},
            {'#', '.', '.', '.', '.', '#', '.', '$', '.', '#', '.', '.', '.', '.', '#'},
            {'#', '.', '.', '.', '.', '#', '#', '#', '#', '#', '.', '.', '.', '.', '#'},
            {'#', '#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', 'S', '.', '#'},
            {'#', '.', '.', '.', '.', '.', '$', '$', '$', '.', '.', '.', '.', '.', '#'},
            {'#', '1', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'o', '#'},
            {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
        };
        
        gameState = true;
        gameMessage1 = "";
        gameMessage2 = "";
    }
    
    // Methods
    public void clearScreen()
    {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
    
    public boolean chance( int a)
    {
        if ( (int) (Math.random() * (100 / a)) == 0 )
        {
            return true;
        }
        
        return false;
    }
    
    public void move( int x, int y, Enemy e)
    {
        char nTile;
        
        nTile = getTile(x, y);
        switch ( nTile )
        {
            case '.':
            setTile(e.x, e.y, nTile);
            setTile(x, y, e.tile);
            break;
        }
    }
    
    public void move( int x, int y, Player p) 
    {
        char nTile;
        
        nTile = getTile(x, y);
        switch ( nTile )
        {
            case '.':
            setTile(p.x, p.y, nTile);
            setTile(x, y, p.tile);
            break;
            
            case '$':
            setTile(p.x, p.y, '.');
            setTile(x, y, p.tile);
            p.add(1);
            p.addMessage("You got 1 gold.\t");
            break;
            
            case 'C':
            setTile(x, y, '.');
            p.add( (int) (Math.random() * 3 + 1));
            p.addMessage("You opened the chest.\t");
            break;
            
            case 'T':
            if ( p.gold < 7 )
            {
                p.addMessage( "You dont't have enough gold.\t");
            }
            else
            {
                setTile(x, y, '.');
                p.att += 2;
                p.gold -= 8;
                p.addMessage("You found a treasure.\t");
            }
            break;
            
            case 'o':
            if ( getTile(7, 4) == '#' )
            {
                setTile(7, 4, '.');
                setTile(5, 6, '.');
                setTile(9, 6, '.');
                setTile(7, 8, '.');
            }
            else
            {
                setTile(7, 4, '#');
                setTile(5, 6, '#');
                setTile(9, 6, '#');
                setTile(7, 8, '#');
            }
            p.addMessage("You stepped on the pressure plate.\t");
            break;
            
            case 's':
            p.hp -= e1.att;
            e1.hp -= p.att;
            p.addMessage("You attacked the snake.\t");
            if ( e1.hp <= 0 )
            {
                setTile( x, y, '.');
                p.gold += 2;
                p.exp += 5;
            }
            break;
            
            case 'S':
            p.hp -= e2.att;
            e2.hp -= p.att;
            p.addMessage("You attacked the snake.\t");
            if ( e2.hp <= 0 )
            {
                setTile( x, y, '.');
                p.gold += 2;
                p.exp += 5;
            }
            break;
            
            case 'g':
            p.hp -= e3.att;
            e3.hp -= p.att;
            p.addMessage("You attacked the goblin.\t");
            if ( e3.hp <= 0 )
            {
                setTile( x, y, '.');
                p.gold += 2;
                p.exp += 5;
            }
            break;
            
            case 'G':
            p.hp -= e4.att;
            e4.hp -= p.att;
            p.addMessage("You attacked the goblin.\t");
            if ( e4.hp <= 0 )
            {
                setTile( x, y, '.');
                p.gold += 2;
                p.exp += 5;
            }
            break;
            
            case '1':
            p1.hp -= p2.att;
            break;
            
            case '2':
            p2.hp -= p1.att;
            break;
            
        }
    }
    
    public void load()
    {
        if ( p1.getTurn() )
        {
            gameMessage1 = " (Your Turn)";
        }
        else
        {
            gameMessage2 = " (Your Turn)";
        }
        
        clearScreen();
        // Player 1
        System.out.println( "Player 1" + gameMessage1);
        System.out.println( "+-------------------------+");
        System.out.println( "Player 1's level: " + p1.level);
        System.out.println( "Player 1's HP: " + p1.hp);
        System.out.println( "Player 1's gold: " + p1.gold);
        System.out.println( p1.getMessage());
        System.out.println( "+-------------------------+");
        
        // Map
        for ( int i = 0; i < map.length; i++ )
        {
            for ( int j = 0; j < map[i].length; j++ )
            {
                System.out.print( map[i][j]);
            }
            System.out.println();
        }
        
        // Player 2
        System.out.println( "Player 2" + gameMessage2);
        System.out.println( "+-------------------------+");
        System.out.println( "Player 2's level: " + p2.level);
        System.out.println( "Player 2's HP: " + p2.hp);
        System.out.println( "Player 2's gold: " + p2.gold);
        System.out.println( p2.getMessage());
        System.out.println( "+-------------------------+");
        
        // Clear messages
        p1.setMessage("");
        p2.setMessage("");
        gameMessage1 = "";
        gameMessage2 = "";
    }
    
    public void process()
    {
        char tile;
        
        for ( int i = 0; i < map.length; i++ )
        {
            for ( int j = 0; j < map[i].length; j++ )
            {
                tile = map[i][j];
                
                switch ( tile )
                {
                    case '1':
                    p1.setPosition(j, i);
                    break;
                    
                    case '2':
                    p2.setPosition(j, i);
                    break;
                    
                    case 's':
                    e1.setPosition(j, i);
                    break;
                    
                    case 'S':
                    e2.setPosition(j, i);
                    break;
                    
                    case 'g':
                    e3.setPosition(j, i);
                    break;
                    
                    case 'G':
                    e4.setPosition(j, i);
                    break;
                }
            }
        }
    }
    
    public void update()
    {
        p1.levelUp();
        p2.levelUp();
        
        // Player movement
        char input;
        
        input = ' ';
        if ( p1.getTurn() )
        {
            if ( chance(10) )
            {
                p1.addMessage( "A thief stole from you!\t");
                p1.add( (int) (Math.random() * 2 - 3));
            }
            
            System.out.print( "> ");
            input = scan.next().charAt(0);
            p1.setDir( input);
            
            switch ( p1.getDir() )
            {
                case 'W':
                case 'w':
                move( p1.x, p1.y - 1, p1);
                break;
                
                case 'A':
                case 'a':
                move( p1.x - 1, p1.y, p1);
                break;
                
                case 'S':
                case 's':
                move( p1.x, p1.y + 1, p1);
                break;
                
                case 'D':
                case 'd':
                move( p1.x + 1, p1.y, p1);
                break;
            }
            
        }
        
        if ( p2.getTurn() )
        {
            if ( chance(10) )
            {
                p2.addMessage( "A thief stole from you!\t");
                p2.add( (int) (Math.random() * 2 - 3));
            }
            
            System.out.print( "> ");
            input = scan.next().charAt(0);
            p2.setDir( input);
            
            switch ( p2.getDir() )
            {
                case 'W':
                case 'w':
                move( p2.x, p2.y - 1, p2);
                break;
                
                case 'A':
                case 'a':
                move( p2.x - 1, p2.y, p2);
                break;
                
                case 'S':
                case 's':
                move( p2.x, p2.y + 1, p2);
                break;
                
                case 'D':
                case 'd':
                move( p2.x + 1, p2.y, p2);
                break;
            }
            
        }
        
        // Check for game over
        if ( p1.hp <= 0 )
        {
            System.out.println("Player 2 wins!");
            System.exit(1);
        }
        else if ( p2.hp <= 0 )
        {
            System.out.println("Player 1 wins!");
            System.exit(1);
        }
        
        
        // Change turns
        p1.changeTurn();
        p2.changeTurn();
        
        
        if ( input == 'q' )
        {
            System.out.println( "\nQuitting...");
            gameState = false;
        }
        
        // Enemy movement
        int enemyDir1 = (int) (Math.random() * 4);
        int enemyDir2 = (int) (Math.random() * 4);
        int enemyDir3 = (int) (Math.random() * 4);
        int enemyDir4 = (int) (Math.random() * 4);
        
        if ( e1.hp > 0 )
        {
            switch ( enemyDir1 )
            {
                case 0:
                move(e1.x, e1.y - 1, e1);
                break;
                
                case 1:
                move(e1.x - 1, e1.y, e1);
                break;
                
                case 2:
                move(e1.x, e1.y + 1, e1);
                break;
                
                case 3:
                move(e1.x + 1, e1.y, e1);
                break;
                
                
            }
        }   
        
        if ( e2.hp > 0 )
        {
            switch ( enemyDir2 )
            {
                case 0:
                move(e2.x, e2.y - 1, e2);
                break;
                
                case 1:
                move(e2.x - 1, e2.y, e2);
                break;
                
                case 2:
                move(e2.x, e2.y + 1, e2);
                break;
                
                case 3:
                move(e2.x + 1, e2.y, e2);
                break;
                
                
            }
        }
        
        if ( e3.hp > 0 )
        {
            switch ( enemyDir3 )
            {
                case 0:
                move(e3.x, e3.y - 1, e3);
                break;
                
                case 1:
                move(e3.x - 1, e3.y, e3);
                break;
                
                case 2:
                move(e3.x, e3.y + 1, e3);
                break;
                
                case 3:
                move(e3.x + 1, e3.y, e3);
                break;
                
                
            }
        }
        
        if ( e4.hp > 0 )
        {
            switch ( enemyDir4 )
            {
                case 0:
                move(e4.x, e4.y - 1, e4);
                break;
                
                case 1:
                move(e4.x - 1, e4.y, e4);
                break;
                
                case 2:
                move(e4.x, e4.y + 1, e4);
                break;
                
                case 3:
                move(e4.x + 1, e4.y, e4);
                break;        
            }
        }
    }
    
    public boolean isRunning()
    {
        return gameState;
    }
    
    // Setters
    public void setTile(int x, int y, char tile)
    {
        map[y][x] = tile;
    }
    
    // Getters
    public char getTile(int x, int y)
    {
        return map[y][x];
    }
    
}