import java.util.Scanner;

/**
 * simple 2-player game 
 * @author Mehmet Feyyaz Küçük
 * @version 02.01.2021
*/ 
public class Main
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        
        // Variables
        Game game = new Game();
        
        // Program Code
        while ( game.isRunning() )
        {
            game.load();
            game.process();
            game.update();
        }
        
        // Closing Scanner
        scan.close();
        
    }
    
}